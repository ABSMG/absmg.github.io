#!/usr/bin/env python3
"""Validate the starter product catalogue using only Python's standard library."""
import json
from pathlib import Path

path = Path(__file__).resolve().parents[1] / "catalog.json"
data = json.loads(path.read_text(encoding="utf-8"))
assert isinstance(data.get("products"), list) and data["products"], "products must be a non-empty list"
ids = set()
for product in data["products"]:
    assert product.get("id") and product["id"] not in ids, "product IDs must be present and unique"
    ids.add(product["id"])
    assert product.get("name", "").strip(), "product name is required"
    assert isinstance(product.get("price_usd"), (int, float)) and product["price_usd"] > 0, "price_usd must be positive"
    assert product.get("status") in {"concept", "draft", "approved", "published"}, "invalid product status"
assert data.get("checkout_enabled") is False, "checkout must remain disabled until eligibility and payments are verified"
print(f"OK: validated {len(data['products'])} product concepts; checkout remains disabled.")
