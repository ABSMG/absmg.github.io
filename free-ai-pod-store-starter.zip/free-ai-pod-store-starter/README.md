# Free-first AI print-on-demand starter

This is a separate, static pre-launch storefront concept. It does **not** accept orders or payments, and it does not claim that any supplier or payout method is approved for a Tanzania-based creator.

## What's included
- `index.html`: responsive mobile-first storefront preview
- `catalog.json`: editable product concepts and planning prices
- `.github/workflows/validate-store.yml`: free GitHub Actions validation
- `scripts/validate_catalog.py`: standard-library catalogue checks

## Start at TZS 0
1. Open `index.html` locally or publish the folder as a static preview.
2. Replace the sample artwork concepts with original licensed artwork.
3. Before listing products for sale, verify the platform accepts sellers resident in Tanzania, supports your identity documents, and pays out to a method you can use.
4. Confirm actual production cost, shipping, delivery time, refund rules, and whether fulfilment requires you to pay before the payout arrives.
5. Replace planning prices with actual supplier and payment quotes.
6. Only enable checkout after a real end-to-end test and a plan for refunds and delayed payouts.

## Automation safety
Use AI to draft product copy and marketing ideas, not to copy protected characters, logos, or artwork. Require manual approval before publishing listings, changing prices, ordering production, or issuing refunds. Do not store API keys or payment data in this public repository.

## Deployment note
This folder can be used as a static preview. Static hosting alone does not provide secure checkout, a database, order management, supplier integration, or payment processing.
